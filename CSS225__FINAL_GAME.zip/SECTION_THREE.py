#Adam GBoyega-dixon
#css225
#SECTION_THREE
#print stage for story to the user
#create a function to direct the player to the locations():
#create a function for room discription():
    #a tutrtle to help with an image
    #have the user interact with the image
    #a statement that controls the winning and loosing conditions
#End program