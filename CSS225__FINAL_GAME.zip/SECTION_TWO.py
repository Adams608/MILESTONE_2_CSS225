#Adam GBoyega-dixon
#css225
#SECTION_TWO
#def start():
    #have a print statement that says "welcome to stage two"
    #have a print statement that print the story of stage two
    #have a variable for the character


#create a function a to move the player player2()
    #have a choice statement that give the user a input statement
    #create a function to interact with objecets in the game():

#create a function for locations of the objects
#create the function of the winining and loosing condition
