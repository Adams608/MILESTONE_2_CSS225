#Adam GBoyega-dixon
#css225
#Main_Character
#Creat a players class with different attributes
#class Main_Character:
#define your variables here
    #name = ""
    #attack = 4
    #damage =
    #inventory = []
    #HIit_points = 20
    #skills = ["sword","climbing", "swimming"]
    #strength =