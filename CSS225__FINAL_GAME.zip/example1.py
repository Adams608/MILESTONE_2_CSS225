#Adam GBoyega-dixon
#css225
#SECTION_FOUR
#ask for the user name
#print stage for story to the user
#create a function for room discription():
    #A while loop for room description
    #create a function for the winning and loosing condition