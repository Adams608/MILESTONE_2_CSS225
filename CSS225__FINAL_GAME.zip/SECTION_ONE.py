#Adam GBoyega-dixon
#css225
#SECTION_ONE
#THIS SECTION WOULD AN INTRODUCTION TO THE GAME
#name = input("what is your name?")
#player = name
#def start():
# story = ("the game story")
# print("welcome to the game")
# name = input("what is your name")
# greet = "Welcome to the game" + name
# print(greet + story)
# print("Press Y to start and N to end the game")
# choice = input("Enter your choice")
# if choice == 'Y':
#       print("Begin this game")r 
# elif choice == 'N':
#      print("End game")
    #give the user option and things to do, like a direction
    #an attack function to help fight
#def attack():
    #Hit_point = 20
    #damage = random.randint(-1,-100)
    #print("You have to daefeat the monster to complete this level")
    #create variable for damage
    #list of weapons the player posses
#     #End program
# def take_damage():
#     if character.is_beaten == True:
#         beaten : random.randint(1,100)
#         print  random.randint(1,100)
#     print("game over")
#     exit()
X = 5
Y = 2
Z = 3
if X < Y and X < Z:
    print("a")
elif Y < X and Y < Z:
    print("b")
else:
    print("c")